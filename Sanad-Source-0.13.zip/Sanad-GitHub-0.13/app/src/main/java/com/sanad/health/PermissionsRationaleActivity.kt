package com.sanad.health
import android.app.Activity
import android.os.Bundle
import android.widget.TextView
class PermissionsRationaleActivity : Activity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(I18n.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply { text = I18n.t(R.string.ui_317); textSize = 20f; setPadding(36,64,36,36) })
    }
}
