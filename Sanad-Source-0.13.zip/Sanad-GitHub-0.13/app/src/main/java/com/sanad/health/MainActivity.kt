package com.sanad.health

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.UUID
import java.text.DateFormat
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*
import android.text.InputType
import android.util.Patterns
import android.text.Editable
import android.text.TextWatcher
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : Activity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(I18n.wrap(newBase))
    }

    private enum class Screen(private val labelId: Int, val icon: String = "") {
        WELCOME(R.string.ui_23), PENDING(R.string.ui_24), HOME(R.string.ui_25, "⌂"), TASKS(R.string.ui_26, "✓"), MEMBERS(R.string.ui_27), ACCOUNT(R.string.ui_28),
        READINGS(R.string.ui_29, "♡"), RECORD(R.string.ui_30, "✚"), DOCTOR(R.string.ui_31, "♧"),
        CARE(R.string.ui_32, "♧"), PATIENTS(R.string.ui_33), PATIENT(R.string.ui_34),
        MEDICATIONS(R.string.ui_35), LABS(R.string.ui_36), ALERTS(R.string.ui_37);
        val label: String get() = I18n.t(labelId)
    }

    private val readingTypes = listOf("ضغط الدم (mmHg)", "الأكسجين (%)", "السكر (mg/dL)")

    private enum class Role { FAMILY, DOCTOR }

    private val green = Color.rgb(20, 103, 89)
    private val ink = Color.rgb(23, 57, 51)
    private val backgroundColor = Color.rgb(242, 245, 239)
    private val border = Color.rgb(227, 233, 228)
    private val muted = Color.rgb(91, 111, 104)
    private val auth by lazy {
        if (FirebaseApp.getApps(this).any { it.name == FirebaseApp.DEFAULT_APP_NAME }) {
            FirebaseAuth.getInstance()
        } else null
    }
    private val credentialManager by lazy { CredentialManager.create(this) }
    private val accountScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val googleClientId by lazy {
        val resource = resources.getIdentifier("default_web_client_id", "string", packageName)
        if (resource == 0) null else getString(resource).takeIf { it.isNotBlank() }
    }
    private var selectedAccountType: Role? = null
    private var signedInUid: String? = null
    private var authenticating = false
    private var taskFilter = 0
    private var taskQuery = ""
    private var restoredScreen: Screen? = null
    private var authMessage = ""
    private val prefs
        get() = getSharedPreferences(signedInUid?.let { "sanad_account_$it" } ?: "sanad_demo", MODE_PRIVATE)
    private data class Family(val name: String, val patient: String, val file: String)
    private val demoFamilies: List<Family>
        get() {
            val stored = JSONArray(prefs.getString("doctor_families", "[]"))
            val added = (0 until stored.length()).map { i -> val f = stored.getJSONObject(i); Family(f.getString("name"), f.getString("patient"), f.getString("file")) }
            return listOf(
        Family(I18n.t(R.string.ui_38), I18n.t(R.string.ui_39), "DEMO-001"),
        Family(I18n.t(R.string.ui_40), I18n.t(R.string.ui_41), "DEMO-002")
    ) + added + cloudLinks.filter { it.getString("status") == "accepted" }.map { Family(it.getString("familyName") ?: I18n.t(R.string.ui_42), it.getString("familyName") ?: I18n.t(R.string.ui_43), "CLOUD-${it.id}") }
        }
    private var selectedFamily = 0
    private var role: Role? = null
    private var current = Screen.WELCOME
    private lateinit var page: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoredScreen = savedInstanceState?.getString("screen")?.let { runCatching { Screen.valueOf(it) }.getOrNull() }
        taskFilter = savedInstanceState?.getInt("taskFilter") ?: 0
        taskQuery = savedInstanceState?.getString("taskQuery").orEmpty()
        selectedFamily = savedInstanceState?.getInt("family", 0)?: 0
        selectedAccountType = savedInstanceState?.getString("accountType")?.let(Role::valueOf)
        val user = auth?.currentUser
        if (user != null) {
            authenticating = true
            show(Screen.WELCOME)
            openAccount(user)
        } else {
            show(Screen.WELCOME)
        }
    }

    override fun onDestroy() {
        stopCloud()
        accountScope.cancel()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("accountType", selectedAccountType?.name)
        outState.putString("screen", current.name)
        outState.putInt("taskFilter", taskFilter)
        outState.putString("taskQuery", taskQuery)
        outState.putInt("family", selectedFamily)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val parent = when (current) {
            Screen.WELCOME -> return super.onBackPressed()
            Screen.HOME -> Screen.WELCOME
            Screen.MEDICATIONS, Screen.LABS -> Screen.RECORD
            Screen.RECORD -> if (role == Role.DOCTOR) Screen.PATIENT else Screen.HOME
            Screen.PATIENT -> if (role == Role.DOCTOR) Screen.HOME else Screen.RECORD
            Screen.ALERTS -> Screen.CARE
            Screen.MEMBERS -> Screen.TASKS
            Screen.ACCOUNT -> if (prefs.getString("requestedAccountType", "") == "DOCTOR" && role != Role.DOCTOR) Screen.PENDING else Screen.HOME
            else -> Screen.HOME
        }
        if ((current == Screen.HOME || current == Screen.PENDING) && signedInUid != null) return super.onBackPressed()
        show(parent)
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density + .5f).toInt()

    private fun panel(color: Int, radius: Int, outline: Boolean = false) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (outline) setStroke(dp(1), border)
        }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun label(value: String, size: Float, bold: Boolean = false, color: Int = ink) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun LinearLayout.append(view: View, gap: Int = 10) {
        addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(gap) })
    }

    private fun button(value: String, filled: Boolean = true, action: () -> Unit) =
        Button(this).apply {
            text = value
            textSize = 14f
            isAllCaps = false
            minHeight = dp(48)
            setTextColor(if (filled) Color.WHITE else green)
            background = panel(if (filled) green else Color.WHITE, 12, !filled)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { action() }
        }

    private fun card(title: String, detail: String? = null) = column().apply {
        background = panel(Color.WHITE, 16, true)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        append(label(title, 16f, true), if (detail == null) 0 else 7)
        if (detail != null) append(label(detail, 14f, color = muted), 0)
    }

    private fun linkCard(title: String, detail: String, target: Screen) {
        page.append(button(if (I18n.language == "ar") "$title  ‹" else "$title  ›", false) { show(target) })
    }

    private fun show(screen: Screen) {
        messageSubscription?.remove(); messageSubscription = null
        cloudLabel = null; cloudList = null
        current = if (role == null) Screen.WELCOME else screen
        if (current == Screen.WELCOME) role = null
        val root = column().apply {
            layoutDirection = I18n.direction
            setBackgroundColor(backgroundColor)
            setOnApplyWindowInsetsListener { view, insets ->
                @Suppress("DEPRECATION")
                view.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
                if (android.os.Build.VERSION.SDK_INT >= 30) WindowInsets.CONSUMED else insets
            }
        }
        page = column().apply { setPadding(dp(18), dp(22), dp(18), dp(16)) }
        root.addView(ScrollView(this).apply { addView(page) }, LinearLayout.LayoutParams(-1, 0, 1f))
        if (current != Screen.WELCOME) root.addView(familyNavigation())
        setContentView(root)
        root.requestApplyInsets()

        if (current != Screen.WELCOME) {
            page.append(label(current.label, 22f, true), 10)
            if (current == Screen.HOME || current == Screen.PENDING) {
                val mode = if (signedInUid == null) I18n.t(R.string.ui_44) else I18n.t(R.string.ui_45)
                page.append(label(
                    (if (current == Screen.PENDING) I18n.t(R.string.ui_24) else if (role == Role.FAMILY) I18n.t(R.string.ui_46) else I18n.t(R.string.ui_47)) + mode,
                    14f, color = muted
                ))
            }
        }

        when (current) {
            Screen.WELCOME -> welcome()
            Screen.PENDING -> {
                doctorIdentity()
                page.append(card(I18n.t(R.string.ui_48),
                    I18n.t(R.string.ui_49)))
                page.append(button(I18n.t(R.string.ui_50)) {
                    authenticating = true
                    show(Screen.WELCOME)
                    auth?.currentUser?.let { openAccount(it) }
                })
            }
            Screen.HOME -> if (role == Role.FAMILY) familyHome() else doctorHome()
            Screen.TASKS -> tasks()
            Screen.MEMBERS -> members()
            Screen.ACCOUNT -> account()
            Screen.READINGS -> readings()
            Screen.RECORD -> record()
            Screen.DOCTOR -> doctorLink()
            Screen.CARE -> care()
            Screen.PATIENTS -> doctorHome()
            Screen.PATIENT -> patient()
            Screen.MEDICATIONS -> healthEntries("medications", I18n.t(R.string.ui_51), I18n.t(R.string.ui_52), I18n.t(R.string.ui_53))
            Screen.LABS -> healthEntries("labs", I18n.t(R.string.ui_54), I18n.t(R.string.ui_55), I18n.t(R.string.ui_56))
            Screen.ALERTS -> taskAlerts()
        }
        if (current == Screen.HOME || current == Screen.PENDING) {
            page.append(button(I18n.t(R.string.ui_28), false) { show(Screen.ACCOUNT) })
            val accountLabel = if (signedInUid == null) I18n.t(R.string.ui_57) else I18n.t(R.string.ui_58)
            page.append(button(accountLabel, false) {
                if (signedInUid != null) {
                    stopCloud()
                    auth?.signOut()
                    authenticating = true
                    accountScope.launch {
                        try {
                            credentialManager.clearCredentialState(ClearCredentialStateRequest())
                        } catch (_: ClearCredentialException) {
                            // Firebase has already signed out.
                        }
                        authenticating = false
                        show(Screen.WELCOME)
                    }
                }
                signedInUid = null
                selectedAccountType = null
                taskQuery = ""
                taskFilter = 0
                authMessage = ""
                show(Screen.WELCOME)
            })
        }
        if (current in listOf(Screen.PATIENTS, Screen.PATIENT, Screen.MEDICATIONS, Screen.LABS, Screen.ALERTS, Screen.ACCOUNT) ||
            (role == Role.DOCTOR && current == Screen.RECORD)) {
            page.append(button(I18n.t(R.string.ui_59), false) { onBackPressed() })
        }
        if (cloudReadOnly() && current in listOf(Screen.PATIENT, Screen.RECORD, Screen.READINGS, Screen.TASKS, Screen.MEDICATIONS, Screen.LABS, Screen.MEMBERS)) {
            page.append(label(I18n.t(R.string.ui_60), 13f, color = muted))
            lockCloudEdits(page)
        }
    }

    private fun languageSelector() {
        page.append(button(if (I18n.language == "ar") "English" else "العربية", false) {
            I18n.setLanguage(this, if (I18n.language == "ar") "en" else "ar")
            if (role != null) show(Screen.HOME)
            recreate()
        })
    }

    private fun welcome() {
        languageSelector()
        page.setPadding(dp(20), dp(32), dp(20), dp(20))
        val mark = ImageView(this).apply {
            setImageResource(R.drawable.sanad_icon_foreground)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = panel(green, 16)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        page.addView(mark, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(18) })
        page.append(label(I18n.t(R.string.ui_23), 26f, true))
        page.append(label(I18n.t(R.string.ui_61), 16f), 22)

        if (authenticating) {
            page.append(card(I18n.t(R.string.ui_62)))
            return
        }
        if (authMessage.isNotEmpty()) page.append(label(authMessage, 14f, color = muted))
        val ready = auth != null
        val clientId = googleClientId
        page.append(button(I18n.t(R.string.ui_63), false) {
            if (ready && clientId != null) signInWithGoogle(clientId)
            else Toast.makeText(this, I18n.t(R.string.ui_64), Toast.LENGTH_LONG).show()
        })
        page.append(label(I18n.t(R.string.ui_65), 18f, true))
        val form = card(I18n.t(R.string.ui_66))
        val email = input(I18n.t(R.string.ui_67)).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            textDirection = View.TEXT_DIRECTION_LTR
            setAutofillHints(View.AUTOFILL_HINT_EMAIL_ADDRESS)
        }
        val password = input(I18n.t(R.string.ui_68)).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            textDirection = View.TEXT_DIRECTION_LTR
            setAutofillHints(View.AUTOFILL_HINT_PASSWORD)
        }
        form.append(email)
        form.append(password)
        form.append(button(I18n.t(R.string.ui_69)) { submitSanadAccount(email, password, false) })
        form.append(button(I18n.t(R.string.ui_70), false) { submitSanadAccount(email, password, true) }, 0)
        form.append(button(I18n.t(R.string.ui_71), false) { resetPassword(email.text.toString().trim()) })
        page.append(form)
        if (!ready) page.append(label(I18n.t(R.string.ui_72), 14f, color = muted))
    }

    private fun submitSanadAccount(email: EditText, password: EditText, register: Boolean) {
        val service = auth
        if (service == null) {
            Toast.makeText(this, I18n.t(R.string.ui_73), Toast.LENGTH_LONG).show()
            return
        }
        if (authenticating) return
        val address = email.text.toString().trim()
        val secret = password.text.toString()
        if (!Patterns.EMAIL_ADDRESS.matcher(address).matches()) {
            email.error = I18n.t(R.string.ui_74)
            return
        }
        if (secret.isEmpty() || (register && secret.length < 6)) {
            password.error = if (register) I18n.t(R.string.ui_75) else I18n.t(R.string.ui_76)
            return
        }
        authenticating = true
        authMessage = ""
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .hideSoftInputFromWindow(password.windowToken, 0)
        password.text.clear()
        show(Screen.WELCOME)
        val request = if (register) service.createUserWithEmailAndPassword(address, secret)
            else service.signInWithEmailAndPassword(address, secret)
        request.addOnCompleteListener { result ->
            if (isDestroyed || isFinishing || current != Screen.WELCOME) return@addOnCompleteListener
            val user = if (result.isSuccessful) result.result?.user else null
            if (user != null) openAccount(user)
            else finishSignInAttempt(
                if (register) I18n.t(R.string.ui_77)
                else I18n.t(R.string.ui_78)
            )
        }
    }

    private fun signInWithGoogle(clientId: String) {
        val service = auth ?: return
        if (authenticating) return
        authenticating = true
        authMessage = ""
        show(Screen.WELCOME)

        accountScope.launch {
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(GetSignInWithGoogleOption.Builder(clientId).build())
                .build()
            val idToken = try {
                val credential = credentialManager.getCredential(this@MainActivity, request).credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    GoogleIdTokenCredential.createFrom(credential.data).idToken
                } else null
            } catch (_: GetCredentialCancellationException) {
                finishSignInAttempt()
                return@launch
            } catch (_: GetCredentialException) {
                null
            } catch (_: GoogleIdTokenParsingException) {
                null
            }

            if (current != Screen.WELCOME) return@launch
            if (idToken == null) {
                finishSignInAttempt(I18n.t(R.string.ui_79))
                return@launch
            }

            service.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null))
                .addOnCompleteListener { result ->
                    if (isDestroyed || isFinishing || current != Screen.WELCOME) return@addOnCompleteListener
                    val user = if (result.isSuccessful) result.result?.user else null
                    if (user != null) openAccount(user)
                    else finishSignInAttempt(I18n.t(R.string.ui_80))
                }
        }
    }

    private fun finishSignInAttempt(message: String = "") {
        if (current != Screen.WELCOME) return
        authenticating = false
        authMessage = message
        show(Screen.WELCOME)
    }

    private fun openAccount(user: FirebaseUser) {
        cloud.accountRole(user.uid, null) { assigned, error ->
            if (isDestroyed || isFinishing || auth?.currentUser?.uid != user.uid) return@accountRole
            authenticating = false
            if (error != null) { finishSignInAttempt(I18n.t(R.string.ui_81)); return@accountRole }
            if (assigned == null) {
                show(Screen.WELCOME)
                AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_82))
                    .setItems(arrayOf(I18n.t(R.string.ui_42), I18n.t(R.string.ui_83))) { _, index ->
                        val chosen = if (index == 0) Role.FAMILY else Role.DOCTOR
                        AlertDialog.Builder(this).setTitle((I18n.t(R.string.ui_86) + " " + if (index == 0) I18n.t(R.string.ui_42) else I18n.t(R.string.ui_83)))
                            .setMessage(I18n.t(R.string.ui_85))
                            .setNegativeButton(I18n.t(R.string.ui_59)) { _, _ -> openAccount(user) }
                            .setPositiveButton(I18n.t(R.string.ui_86)) { _, _ ->
                                authenticating = true; show(Screen.WELCOME)
                                cloud.accountRole(user.uid, chosen.name) { saved, failure ->
                                    if (auth?.currentUser?.uid != user.uid || isDestroyed) return@accountRole
                                    authenticating = false
                                    if (failure != null || saved == null) finishSignInAttempt(I18n.t(R.string.ui_87))
                                    else finishAccount(user, saved)
                                }
                            }.setCancelable(false).show()
                    }.setCancelable(false).show()
            } else finishAccount(user, assigned)
        }
    }

    private fun finishAccount(user: FirebaseUser, assigned: String) {
        signedInUid = user.uid
        val savedRole = Role.valueOf(assigned)
        selectedAccountType = savedRole
        getSharedPreferences("sanad_account_${user.uid}", MODE_PRIVATE).edit()
            .putString("requestedAccountType", assigned).apply()
        selectedFamily = 0
        enter(savedRole)
    }

    private fun enter(selected: Role) {
        role = selected
        startCloud()
        val target = restoredScreen
        restoredScreen = null
        show(if (target != null && target !in listOf(Screen.WELCOME, Screen.PENDING)) target else Screen.HOME)
    }

    private fun familyNavigation() = LinearLayout(this).apply {
        layoutDirection = I18n.direction
        setBackgroundColor(Color.WHITE)
        val tabs = if (role == Role.DOCTOR) listOf(Screen.HOME, Screen.PATIENTS, Screen.CARE, Screen.ACCOUNT) else listOf(Screen.HOME, Screen.TASKS, Screen.RECORD, Screen.CARE)
        val active = when (current) {
            Screen.PATIENT, Screen.MEDICATIONS, Screen.LABS -> Screen.RECORD
            Screen.ALERTS -> Screen.CARE
            Screen.MEMBERS -> Screen.TASKS
            else -> current
        }
        for (tab in tabs) {
            val item = Button(context).apply {
                val icon = when (tab) { Screen.HOME -> "⌂"; Screen.TASKS -> "✓"; Screen.RECORD -> "✚"; Screen.PATIENTS -> "♙"; Screen.ACCOUNT -> "⚙"; else -> "♡" }
                val caption = if (tab == Screen.ACCOUNT) I18n.t(R.string.ui_28) else tab.label
                text = android.text.SpannableString("$icon\n$caption").apply {
                    setSpan(android.text.style.AbsoluteSizeSpan(23, true), 0, icon.length, 0)
                }
                contentDescription = tab.label
                isAllCaps = false
                isSelected = tab == active
                textSize = 13f
                gravity = Gravity.CENTER
                minWidth = 0
                setPadding(0, 0, 0, 0)
                setTextColor(if (isSelected) green else muted)
                background = panel(if (isSelected) backgroundColor else Color.WHITE, 0)
                setOnClickListener { show(tab) }
            }
            addView(item, LinearLayout.LayoutParams(0, dp(66), 1f))
        }
    }

    private fun familyHome() {
        val items = loadTasks()
        val done = items.count { it.done }
        page.append(column().apply {
            background = panel(green, 18)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            append(label(I18n.t(R.string.ui_88), 20f, true, Color.WHITE))
            append(ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = items.size.coerceAtLeast(1)
                progress = done
                progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            }, 6)
            append(label(I18n.pick("$done من ${items.size} مهام مكتملة", "$done of ${items.size} tasks completed"), 13f, color = Color.WHITE), 0)
        })
        val pending = items.filter { !it.done }.minByOrNull { if (it.dueAt == 0L) Long.MAX_VALUE else it.dueAt }
        val overdue = items.count { !it.done && it.dueAt != 0L && it.dueAt < System.currentTimeMillis() }
        page.append(label(I18n.pick("أعضاء الأسرة: ${loadMembers().size} · مهام متأخرة: $overdue", "Family members: ${loadMembers().size} · Overdue tasks: $overdue"), 14f))
        page.append(button(I18n.t(R.string.ui_91), false) { show(Screen.MEMBERS) })
        linkCard(I18n.t(R.string.ui_92), pending?.title ?: if (items.isEmpty()) I18n.t(R.string.ui_93) else I18n.t(R.string.ui_94), Screen.TASKS)

        page.append(label(I18n.t(R.string.ui_95), 18f, true), 8)
        val readings = JSONArray(prefs.getString("readings", "[]"))
        for (kind in readingTypes) {
            val latest = (0 until readings.length()).map { readings.getJSONObject(it) }.filter { it.optString("type") == kind }.maxByOrNull { it.optLong("at") }
            page.append(card(I18n.measurement(kind), latest?.let { it.getString("value") + " · " + formatDue(it.getLong("at")) } ?: I18n.t(R.string.ui_99)))
        }
        page.append(button(I18n.t(R.string.ui_100), false) { show(Screen.READINGS) })

        page.append(card(I18n.t(R.string.ui_101)).apply {
            append(button(I18n.t(R.string.ui_102)) { show(Screen.DOCTOR) }, 0)
        })
        page.append(card(I18n.t(R.string.ui_103), I18n.pick("أُنجزت $done مهام، تبقى ${items.size - done}.", "$done completed, ${items.size - done} remaining.")))
    }

    private fun doctorIdentity() {
        if (signedInUid == null) return
        val stored = prefs.getString("doctor_short_id", null)
        if (stored == null) {
            page.append(card(I18n.t(R.string.ui_105), I18n.t(R.string.ui_106)))
            val name = input(I18n.t(R.string.ui_107)).apply { setText(auth?.currentUser?.displayName.orEmpty()) }
            page.append(name)
            page.append(button(I18n.t(R.string.ui_108)) {
                val value = name.text.toString().trim()
                val letters = value.codePoints().toArray().filter { Character.isLetter(it) }
                if (letters.size < 2) {
                    name.error = I18n.t(R.string.ui_109); return@button
                }
                registerCloudDoctor(value)
            })
            return
        }
        page.append(card(I18n.t(R.string.ui_110), prefs.getString("doctor_name", "")).apply {
            append(label(stored, 22f, true, green).apply { setTextIsSelectable(true) })
            append(button(I18n.t(R.string.ui_111), false) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText(I18n.t(R.string.ui_110), stored))
                Toast.makeText(this@MainActivity, I18n.t(R.string.ui_112), Toast.LENGTH_SHORT).show()
            })
            if (!prefs.getBoolean("doctor_cloud_registered", false)) append(button(I18n.t(R.string.ui_113)) { registerCloudDoctor(prefs.getString("doctor_name", "").orEmpty()) })
        })
    }

    private fun doctorHome() {
        page.append(label(I18n.t(R.string.ui_47), 20f, true))
        page.append(button(I18n.t(R.string.ui_114)) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE) }, 402) })
        doctorIdentity()
        page.append(label(I18n.t(R.string.ui_115), 18f, true))
        cloudLabel = label(cloudStatus, 14f, color = muted).also { page.append(it) }
        cloudList = column().also { page.append(it) }
        renderCloudLinks()
        page.append(label(I18n.t(R.string.ui_116), 17f, true))
        page.append(button(I18n.t(R.string.ui_117), false) {
            val name = input(I18n.t(R.string.ui_118))
            val patient = input(I18n.t(R.string.ui_119))
            val form = column().apply { append(name); append(patient) }
            val dialog = AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_120)).setView(form).setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_122), null).create()
            dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (name.text.isBlank() || patient.text.isBlank()) { name.error = I18n.t(R.string.ui_123); return@setOnClickListener }
                val list = JSONArray(prefs.getString("doctor_families", "[]"))
                list.put(JSONObject().put("name", name.text.toString().trim()).put("patient", patient.text.toString().trim()).put("file", "SAN-" + UUID.randomUUID().toString().take(8)))
                prefs.edit().putString("doctor_families", list.toString()).apply()
                dialog.dismiss(); show(Screen.HOME)
            } }; dialog.show()
        })
        val search = input(I18n.t(R.string.ui_124))
        page.append(search)
        val families = column()
        page.append(families)
        fun displayFamilies(query: String) {
            families.removeAllViews()
            val matches = demoFamilies.withIndex().filter {
                query.isBlank() || listOf(it.value.name, it.value.patient, it.value.file).any { text ->
                    text.contains(query.trim(), ignoreCase = true)
                }
            }
            matches.forEach { (index, family) ->
                families.append(card(family.name, "${family.file} · ${family.patient}").apply {
                    append(button(I18n.t(R.string.ui_125)) {
                        if (family.file.startsWith("CLOUD-")) openCloudFamily(family.file.removePrefix("CLOUD-"))
                        else { recordSubscription?.remove(); cloudRecordUid = null; selectedFamily = index; show(Screen.PATIENT) }
                    }, 0)
                })
            }
            if (matches.isEmpty()) families.append(label(I18n.t(R.string.ui_126), 14f, color = muted))
        }
        displayFamilies("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                displayFamilies(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun patient() {
        if (role == Role.FAMILY) { patientProfile(); return }
        val family = demoFamilies[selectedFamily]
        val profile = JSONObject(prefs.getString(recordKey("patient_profile"), "{}"))
        if (profile.length() > 0) {
            page.append(card(I18n.t(R.string.ui_127), listOf("name" to I18n.t(R.string.ui_128), "birth" to I18n.t(R.string.ui_129), "allergies" to I18n.t(R.string.ui_130), "conditions" to I18n.t(R.string.ui_131), "contact" to I18n.t(R.string.ui_132), "notes" to I18n.t(R.string.ui_133)).mapNotNull { (key, title) -> profile.optString(key).takeIf { it.isNotBlank() }?.let { "$title: $it" } }.joinToString("\n")))
            page.append(label(I18n.t(R.string.ui_134) + formatDue(prefs.getLong(recordKey("exportedAt"), 0)), 13f, color = muted))
        }
        page.append(card(
            if (role == Role.DOCTOR) family.name else I18n.t(R.string.ui_135),
            if (role == Role.DOCTOR) "${family.patient} · ${family.file}" else I18n.t(R.string.ui_136)
        ))
        if (role == Role.DOCTOR) {
            page.append(label(I18n.t(R.string.ui_137), 18f, true))
            page.append(card(I18n.t(R.string.ui_138)).apply {
                append(button(I18n.t(R.string.ui_139), false) { show(Screen.DOCTOR) })
            })
            linkCard(I18n.t(R.string.ui_30), I18n.t(R.string.ui_140), Screen.RECORD)
            linkCard(I18n.t(R.string.ui_92), I18n.t(R.string.ui_141), Screen.TASKS)
            linkCard(I18n.t(R.string.ui_29), I18n.t(R.string.ui_142), Screen.READINGS)
        } else {
            linkCard(I18n.t(R.string.ui_35), I18n.t(R.string.ui_143), Screen.MEDICATIONS)
            linkCard(I18n.t(R.string.ui_36), I18n.t(R.string.ui_144), Screen.LABS)
        }
    }

    private fun record() {
        if (role == Role.FAMILY) linkCard(I18n.t(R.string.ui_34), I18n.t(R.string.ui_145), Screen.PATIENT)
        linkCard(I18n.t(R.string.ui_35), I18n.t(R.string.ui_143), Screen.MEDICATIONS)
        linkCard(I18n.t(R.string.ui_36), I18n.t(R.string.ui_144), Screen.LABS)
    }

    private fun readings() {
        page.append(label(I18n.t(R.string.ui_146), 20f, true))
        page.append(button(I18n.t(R.string.ui_147)) { readingEditor() })
        val values = JSONArray(prefs.getString(recordKey("readings"), "[]"))
        if (values.length() == 0) page.append(card(I18n.t(R.string.ui_148)))
        for (i in values.length() - 1 downTo 0) {
            val item = values.getJSONObject(i)
            page.append(card(I18n.measurement(item.getString("type")), item.getString("value") + "\n" + formatDue(item.getLong("at")) + "\n" + item.optString("notes")).apply {
                append(button(I18n.t(R.string.ui_149), false) {
                    AlertDialog.Builder(this@MainActivity).setTitle(I18n.t(R.string.ui_150)).setNegativeButton(I18n.t(R.string.ui_121), null)
                        .setPositiveButton(I18n.t(R.string.ui_151)) { _, _ ->
                            val remaining = JSONArray()
                            for (j in 0 until values.length()) if (j != i) remaining.put(values.getJSONObject(j))
                            prefs.edit().putString(recordKey("readings"), remaining.toString()).apply(); show(Screen.READINGS)
                        }.show()
                }, 0)
            })
        }
        if (role == Role.FAMILY) page.append(card(I18n.t(R.string.ui_152), I18n.t(R.string.ui_153)).apply {
            append(button(I18n.t(R.string.ui_154), false) { startActivity(Intent(this@MainActivity, HealthActivity::class.java)) }, 0)
        })
    }
    private fun readingEditor() {
        val kind = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(I18n.t(R.string.ui_96), I18n.t(R.string.ui_97), I18n.t(R.string.ui_98))) }
        val first = input(I18n.t(R.string.ui_155)).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val second = input(I18n.t(R.string.ui_156)).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val notes = input(I18n.t(R.string.ui_157))
        var measuredAt = System.currentTimeMillis()
        val time = label(formatDue(measuredAt), 15f)
        val form = column().apply {
            layoutDirection = I18n.direction; setPadding(dp(18), dp(12), dp(18), dp(12))
            append(kind); append(first); append(second); append(notes); append(time)
            append(button(I18n.t(R.string.ui_158), false) {
                val c = Calendar.getInstance().apply { timeInMillis = measuredAt }
                DatePickerDialog(this@MainActivity, { _, y, m, d ->
                    c.set(y, m, d)
                    TimePickerDialog(this@MainActivity, { _, h, minute ->
                        c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, minute); c.set(Calendar.SECOND, 0)
                        measuredAt = c.timeInMillis; time.text = formatDue(measuredAt)
                    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            })
        }
        kind.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                second.visibility = if (position == 0) View.VISIBLE else View.GONE
                first.hint = when (position) { 0 -> I18n.t(R.string.ui_159); 1 -> I18n.t(R.string.ui_97); else -> I18n.t(R.string.ui_98) }
            }
        }
        val dialog = AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_160)).setView(ScrollView(this).apply { addView(form) }).setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_122), null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val a = first.text.toString().toDoubleOrNull()
            val b = second.text.toString().toDoubleOrNull()
            val k = kind.selectedItemPosition
            if (a == null || !a.isFinite() || a <= 0 || (k == 1 && a > 100)) { first.error = I18n.t(R.string.ui_161); return@setOnClickListener }
            if (k == 0 && (b == null || b <= 0 || b >= a)) { second.error = I18n.t(R.string.ui_162); return@setOnClickListener }
            if (measuredAt > System.currentTimeMillis() + 60000) { Toast.makeText(this, I18n.t(R.string.ui_163), Toast.LENGTH_LONG).show(); return@setOnClickListener }
            val value = when (k) { 0 -> "$a / $b mmHg"; 1 -> "$a %"; else -> "$a mg/dL" }
            val items = JSONArray(prefs.getString(recordKey("readings"), "[]"))
            items.put(JSONObject().put("type", readingTypes[k]).put("value", value).put("at", measuredAt).put("notes", notes.text.toString()))
            prefs.edit().putString(recordKey("readings"), items.toString()).apply()
            dialog.dismiss(); show(Screen.READINGS)
        } }; dialog.show()
    }

    private fun care() {
        if (role == Role.FAMILY) {
            linkCard(I18n.t(R.string.ui_29), I18n.t(R.string.ui_164), Screen.READINGS)
            linkCard(I18n.t(R.string.ui_31), I18n.t(R.string.ui_165), Screen.DOCTOR)
            linkCard(I18n.t(R.string.ui_27), I18n.t(R.string.ui_166), Screen.MEMBERS)
        }
        linkCard(I18n.t(R.string.ui_28), I18n.t(R.string.ui_167), Screen.ACCOUNT)
        if (role == Role.FAMILY) {
            val items = loadTasks()
            page.append(card(I18n.t(R.string.ui_103), I18n.pick("${items.count { it.done }} من ${items.size} مهام مكتملة على هذا الجهاز.", "${items.count { it.done }} of ${items.size} tasks completed on this device.")))
        } else {
            page.append(button(I18n.t(R.string.ui_169), false) { show(Screen.HOME) })
        }
        linkCard(I18n.t(R.string.ui_37), I18n.t(R.string.ui_170), Screen.ALERTS)
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText
        setSingleLine(true)
        minHeight = dp(52)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = panel(Color.WHITE, 12, true)
    }

    private fun doctorLink() {
        if (role == Role.DOCTOR) { conversation(); return }
        cloudFamilyPanel()
        conversation()
        page.append(label(I18n.t(R.string.ui_171), 16f, true))
        page.append(button(I18n.t(R.string.ui_172)) {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_TITLE, "Sanad-family.json") }, 401)
        })
    }

    private data class Member(val id: String, val name: String)
    private data class CareTask(val id: String = UUID.randomUUID().toString(), val title: String,
        val done: Boolean = false, val memberId: String = "", val dueAt: Long = 0, val notes: String = "")

    private fun loadMembers(): List<Member> {
        val array = JSONArray(prefs.getString(recordKey("members"), "[]"))
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            Member(item.getString("id"), item.getString("name"))
        }
    }
    private fun saveMembers(items: List<Member>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs.edit().putString(recordKey("members"), array.toString()).apply()
    }
    private fun members() {
        page.append(label(I18n.t(R.string.ui_173), 14f, color = muted))
        page.append(button(I18n.t(R.string.ui_174)) { memberEditor() })
        val items = loadMembers()
        if (items.isEmpty()) page.append(card(I18n.t(R.string.ui_175)))
        items.forEach { member ->
            page.append(card(member.name).apply {
                append(button(I18n.t(R.string.ui_176), false) { memberEditor(member) })
                append(button(I18n.t(R.string.ui_177), false) {
                    AlertDialog.Builder(this@MainActivity).setTitle(I18n.pick("حذف ${member.name}؟", "Delete ${member.name}?"))
                        .setMessage(I18n.t(R.string.ui_179))
                        .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_151)) { _, _ ->
                            saveTasks(loadTasks().map { if (it.memberId == member.id) it.copy(memberId = "") else it })
                            saveMembers(loadMembers().filterNot { it.id == member.id }); show(Screen.MEMBERS)
                        }.show()
                }, 0)
            })
        }
        page.append(button(I18n.t(R.string.ui_180), false) { show(Screen.TASKS) })
    }
    private fun memberEditor(existing: Member? = null) {
        val name = input(I18n.t(R.string.ui_181)).apply { setText(existing?.name.orEmpty()) }
        val dialog = AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_182)).setView(name)
            .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_122), null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = name.text.toString().trim()
                val items = loadMembers()
                if (value.isBlank()) { name.error = I18n.t(R.string.ui_183); return@setOnClickListener }
                if (items.any { it.id != existing?.id && it.name.equals(value, true) }) {
                    name.error = I18n.t(R.string.ui_184); return@setOnClickListener
                }
                val member = Member(existing?.id ?: UUID.randomUUID().toString(), value)
                saveMembers(if (existing == null) items + member else items.map { if (it.id == member.id) member else it })
                dialog.dismiss(); show(Screen.MEMBERS)
            }
        }
        dialog.show()
    }
    private fun tasks() {
        page.append(button(I18n.pick("أعضاء الأسرة (${loadMembers().size})", "Family members (${loadMembers().size})"), false) { show(Screen.MEMBERS) })
        page.append(button(I18n.t(R.string.ui_186)) { taskEditor() })
        val filters = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(I18n.t(R.string.ui_187), I18n.t(R.string.ui_188), I18n.t(R.string.ui_189), I18n.t(R.string.ui_190), I18n.t(R.string.ui_191)))
            setSelection(taskFilter)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (taskFilter != position) { taskFilter = position; show(Screen.TASKS) }
                }
            }
        }
        page.append(filters)
        val search = input(I18n.t(R.string.ui_192)).apply { setText(taskQuery) }
        page.append(search)
        page.append(button(I18n.t(R.string.ui_193), false) { taskQuery = search.text.toString().trim(); show(Screen.TASKS) })
        if (taskQuery.isNotEmpty()) page.append(button(I18n.t(R.string.ui_194), false) { taskQuery = ""; show(Screen.TASKS) })
        page.append(label(I18n.t(R.string.ui_195), 13f, color = muted))
        val members = loadMembers().associateBy { it.id }
        val now = System.currentTimeMillis()
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val start = today.timeInMillis
        today.add(Calendar.DAY_OF_YEAR, 1)
        val end = today.timeInMillis
        val items = loadTasks().filter { item ->
            val matches = when (taskFilter) {
                1 -> !item.done
                2 -> item.done
                3 -> item.dueAt >= start && item.dueAt < end
                4 -> !item.done && item.dueAt != 0L && item.dueAt < now
                else -> true
            }
            matches && (taskQuery.isBlank() || listOf(item.title, item.notes, members[item.memberId]?.name.orEmpty()).any { it.contains(taskQuery, true) })
        }.sortedWith(compareBy<CareTask> { it.done }.thenBy { if (it.dueAt == 0L) Long.MAX_VALUE else it.dueAt })
        if (items.isEmpty()) page.append(card(I18n.t(R.string.ui_196), I18n.t(R.string.ui_197)))
        items.forEach { item ->
            page.append(card(item.title).apply {
                append(label(I18n.t(R.string.ui_198) + (members[item.memberId]?.name ?: I18n.t(R.string.ui_207)), 14f))
                append(label(I18n.pick("الموعد: ${formatDue(item.dueAt)}", "Due: ${formatDue(item.dueAt)}"), 14f))
                if (item.notes.isNotBlank()) append(label(I18n.pick("ملاحظات: ${item.notes}", "Notes: ${item.notes}"), 14f, color = muted))
                append(CheckBox(this@MainActivity).apply {
                    text = I18n.t(R.string.ui_189); isChecked = item.done; minHeight = dp(48)
                    buttonTintList = android.content.res.ColorStateList.valueOf(green)
                    setOnCheckedChangeListener { _, checked ->
                        saveTasks(loadTasks().map { if (it.id == item.id) it.copy(done = checked) else it })
                        show(Screen.TASKS)
                    }
                })
                append(button(I18n.t(R.string.ui_201), false) { taskEditor(item) })
                append(button(I18n.t(R.string.ui_202), false) {
                    AlertDialog.Builder(this@MainActivity).setTitle(I18n.t(R.string.ui_203))
                        .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_151)) { _, _ ->
                            saveTasks(loadTasks().filterNot { it.id == item.id }); show(Screen.TASKS)
                        }.show()
                }, 0)
            })
        }
    }
    private fun formatDue(value: Long): String = if (value == 0L) I18n.t(R.string.ui_204) else
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, I18n.locale).format(java.util.Date(value))

    private fun taskEditor(existing: CareTask? = null) {
        val title = input(I18n.t(R.string.ui_205)).apply { setText(existing?.title.orEmpty()) }
        val notes = input(I18n.t(R.string.ui_206)).apply {
            setSingleLine(false); minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(existing?.notes.orEmpty())
        }
        val members = loadMembers()
        val responsible = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf(I18n.t(R.string.ui_207)) + members.map { it.name })
            setSelection(members.indexOfFirst { it.id == existing?.memberId } + 1)
        }
        var dueAt = existing?.dueAt ?: 0L
        val due = label(formatDue(dueAt), 16f)
        val form = column().apply {
            layoutDirection = I18n.direction
            setPadding(dp(20), dp(12), dp(20), dp(12))
            append(title); append(label(I18n.t(R.string.ui_208), 15f, true)); append(responsible)
            if (members.isEmpty()) append(label(I18n.t(R.string.ui_209), 13f, color = muted))
            append(due)
            append(button(I18n.t(R.string.ui_210), false) {
                val calendar = Calendar.getInstance().apply { if (dueAt != 0L) timeInMillis = dueAt }
                DatePickerDialog(this@MainActivity, { _, year, month, day ->
                    calendar.set(year, month, day)
                    TimePickerDialog(this@MainActivity, { _, hour, minute ->
                        calendar.set(Calendar.HOUR_OF_DAY, hour); calendar.set(Calendar.MINUTE, minute)
                        calendar.set(Calendar.SECOND, 0); calendar.set(Calendar.MILLISECOND, 0)
                        dueAt = calendar.timeInMillis; due.text = formatDue(dueAt)
                    }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
            })
            append(button(I18n.t(R.string.ui_211), false) { dueAt = 0; due.text = formatDue(dueAt) })
            append(notes)
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) I18n.t(R.string.ui_186) else I18n.t(R.string.ui_201))
            .setView(ScrollView(this).apply { addView(form) })
            .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_122), null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = title.text.toString().trim()
                if (value.isBlank()) { title.error = I18n.t(R.string.ui_212); return@setOnClickListener }
                val task = CareTask(existing?.id ?: UUID.randomUUID().toString(), value, existing?.done ?: false,
                    members.getOrNull(responsible.selectedItemPosition - 1)?.id.orEmpty(), dueAt, notes.text.toString().trim())
                val items = loadTasks()
                saveTasks(if (existing == null) items + task else items.map { if (it.id == task.id) task else it })
                dialog.dismiss(); show(Screen.TASKS)
            }
        }
        dialog.show()
    }
    private fun loadTasks(): List<CareTask> {
        if (!prefs.contains(recordKey("tasks_v2"))) {
            val old = prefs.getString(recordKey("tasks"), "").orEmpty().lineSequence().mapNotNull { line ->
                val fields = line.split("|", limit = 2)
                if (fields.size == 2) CareTask(title = fields[1], done = fields[0] == "1") else null
            }.toList()
            saveTasks(old); return old
        }
        val array = JSONArray(prefs.getString(recordKey("tasks_v2"), "[]"))
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            CareTask(item.getString("id"), item.getString("title"), item.optBoolean("done"),
                item.optString("memberId"), item.optLong("dueAt"), item.optString("notes"))
        }
    }
    private fun saveTasks(items: List<CareTask>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)
            .put("memberId", it.memberId).put("dueAt", it.dueAt).put("notes", it.notes)) }
        prefs.edit().putString(recordKey("tasks_v2"), array.toString()).apply()
    }
    private fun resetPassword(address: String) {
        if (!Patterns.EMAIL_ADDRESS.matcher(address).matches()) {
            Toast.makeText(this, I18n.t(R.string.ui_213), Toast.LENGTH_LONG).show(); return
        }
        val service = auth ?: return
        if (authenticating) return
        authenticating = true
        service.setLanguageCode(I18n.language)
        service.sendPasswordResetEmail(address).addOnCompleteListener { result ->
            authenticating = false
            if (isDestroyed || isFinishing) return@addOnCompleteListener
            AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_214))
                .setMessage(if (result.isSuccessful) I18n.t(R.string.ui_215) else I18n.t(R.string.ui_216))
                .setPositiveButton(I18n.t(R.string.ui_217), null).show()
        }
    }

    private fun account() {
        languageSelector()
        page.append(card(I18n.t(R.string.ui_66), auth?.currentUser?.email ?: I18n.t(R.string.ui_218)))
        page.append(card(I18n.t(R.string.ui_219), if (role == Role.DOCTOR) I18n.t(R.string.ui_83) else I18n.t(R.string.ui_42)))
        page.append(label(I18n.t(R.string.ui_220), 13f, color = muted))
    }

    private fun patientProfile() {
        val profile = JSONObject(prefs.getString("patient_profile", "{}"))
        val fields = listOf("name" to I18n.t(R.string.ui_119), "birth" to I18n.t(R.string.ui_221), "allergies" to I18n.t(R.string.ui_222), "conditions" to I18n.t(R.string.ui_223), "contact" to I18n.t(R.string.ui_224), "notes" to I18n.t(R.string.ui_225))
        val inputs = fields.associate { (key, title) ->
            val field = input(title).apply {
                setText(profile.optString(key))
                if (key in listOf("allergies", "conditions", "notes")) {
                    setSingleLine(false); minLines = 2
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                }
                if (key == "birth") inputType = InputType.TYPE_CLASS_NUMBER
                if (key == "contact") inputType = InputType.TYPE_CLASS_PHONE
            }
            page.append(label(title, 14f, true), 4); page.append(field)
            key to field
        }
        page.append(button(I18n.t(R.string.ui_226)) {
            if (inputs.getValue("name").text.isBlank()) {
                inputs.getValue("name").error = I18n.t(R.string.ui_227); return@button
            }
            val birth = inputs.getValue("birth").text.toString().trim()
            if (birth.isNotBlank() && (birth.toIntOrNull() == null || birth.toInt() !in 1900..Calendar.getInstance().get(Calendar.YEAR))) {
                inputs.getValue("birth").error = I18n.t(R.string.ui_228); return@button
            }
            val value = JSONObject()
            inputs.forEach { (key, field) -> value.put(key, field.text.toString().trim()) }
            prefs.edit().putString("patient_profile", value.toString()).apply()
            Toast.makeText(this, I18n.t(R.string.ui_229), Toast.LENGTH_SHORT).show()
        })
        linkCard(I18n.t(R.string.ui_35), I18n.t(R.string.ui_230), Screen.MEDICATIONS)
        linkCard(I18n.t(R.string.ui_36), I18n.t(R.string.ui_231), Screen.LABS)
    }

    private data class HealthEntry(val id: String, val title: String, val detail: String)
    private fun recordKey(key: String) = if (role == Role.DOCTOR) "doctor_${demoFamilies[selectedFamily].file}_$key" else key
    private fun loadEntries(key: String): List<HealthEntry> {
        val array = JSONArray(prefs.getString(recordKey(key), "[]"))
        return (0 until array.length()).map { index ->
            val value = array.getJSONObject(index)
            HealthEntry(value.getString("id"), value.getString("title"), value.optString("detail"))
        }
    }
    private fun saveEntries(key: String, items: List<HealthEntry>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("detail", it.detail)) }
        prefs.edit().putString(recordKey(key), array.toString()).apply()
    }
    private fun healthEntries(key: String, kind: String, titleHint: String, detailHint: String) {
        page.append(button(I18n.pick("إضافة $kind", "Add $kind")) { entryEditor(key, kind, titleHint, detailHint) })
        val items = loadEntries(key)
        if (items.isEmpty()) page.append(card(I18n.t(R.string.ui_233)))
        items.forEach { item ->
            page.append(card(item.title, item.detail).apply {
                append(button(I18n.t(R.string.ui_234), false) { entryEditor(key, kind, titleHint, detailHint, item) })
                append(button(I18n.t(R.string.ui_151), false) {
                    val target = current
                    AlertDialog.Builder(this@MainActivity).setTitle(I18n.t(R.string.ui_235))
                        .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_151)) { _, _ ->
                            saveEntries(key, loadEntries(key).filterNot { it.id == item.id }); show(target)
                        }.show()
                }, 0)
            })
        }
    }
    private fun entryEditor(key: String, kind: String, titleHint: String, detailHint: String, existing: HealthEntry? = null) {
        val target = current
        val title = input(titleHint).apply { setText(existing?.title.orEmpty()) }
        val detail = input(detailHint).apply {
            setSingleLine(false); minLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(existing?.detail.orEmpty())
        }
        val extras = if (key == "medications" && existing == null) listOf(I18n.t(R.string.ui_236), I18n.t(R.string.ui_237), I18n.t(R.string.ui_238), I18n.t(R.string.ui_239), I18n.t(R.string.ui_240), I18n.t(R.string.ui_241), I18n.t(R.string.ui_242)).map { it to input(it) } else emptyList()
        val form = column().apply {
            layoutDirection = I18n.direction; setPadding(dp(20), dp(12), dp(20), dp(12))
            append(label(titleHint, 14f)); append(title)
            extras.forEach { (caption, field) -> append(label(caption, 14f)); append(field) }
            append(label(detailHint, 14f)); append(detail)
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) I18n.pick("إضافة $kind", "Add $kind") else I18n.pick("تعديل $kind", "Edit $kind"))
            .setView(ScrollView(this).apply { addView(form) }).setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_122), null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = title.text.toString().trim()
                if (value.isBlank()) { title.error = I18n.t(R.string.ui_244); return@setOnClickListener }
                val item = HealthEntry(existing?.id ?: UUID.randomUUID().toString(), value, (extras.filter { it.second.text.isNotBlank() }.map { "${it.first}: ${it.second.text}" } + detail.text.toString().trim()).filter { it.isNotBlank() }.joinToString("\n"))
                val items = loadEntries(key)
                saveEntries(key, if (existing == null) items + item else items.map { if (it.id == item.id) item else it })
                dialog.dismiss(); show(target)
            }
        }
        dialog.show()
    }

    private fun taskAlerts() {
        page.append(card(I18n.t(R.string.ui_245), I18n.t(R.string.ui_246)))
        val now = System.currentTimeMillis()
        val items = loadTasks().filter { !it.done && it.dueAt > 0 }.sortedBy { it.dueAt }
        if (items.isEmpty()) page.append(card(I18n.t(R.string.ui_247)))
        items.forEach { item ->
            page.append(card(if (item.dueAt < now) I18n.pick("متأخرة: ${item.title}", "Overdue: ${item.title}") else item.title, formatDue(item.dueAt)))
        }
        page.append(button(I18n.t(R.string.ui_249), false) { show(Screen.TASKS) })
    }

    @Deprecated("Legacy activity result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || requestCode !in listOf(401, 402)) return
        val uri = data?.data ?: return
        try {
            if (signedInUid == null) error(I18n.t(R.string.ui_250))
            if (requestCode == 401) {
                check(role == Role.FAMILY)
                loadTasks()
                val profile = JSONObject(prefs.getString("patient_profile", "{}"))
                require(profile.optString("name").isNotBlank()) { I18n.t(R.string.ui_251) }
                val id = prefs.getString("export_family_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("export_family_id", it).apply() }
                val snapshot = JSONObject().put("format", "sanad-family-v1").put("id", id).put("at", System.currentTimeMillis()).put("profile", profile)
                for (key in listOf("readings", "members", "tasks_v2", "medications", "labs")) snapshot.put(key, JSONArray(prefs.getString(key, "[]")))
                contentResolver.openOutputStream(uri, "wt")!!.use { it.write(snapshot.toString(2).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, I18n.t(R.string.ui_252), Toast.LENGTH_LONG).show()
            } else {
                check(role == Role.DOCTOR)
                val bytes = contentResolver.openInputStream(uri)!!.use { input -> val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192); while (out.size() <= 2_000_000) { val count = input.read(buffer, 0, minOf(buffer.size, 2_000_001 - out.size())); if (count < 0) break; out.write(buffer, 0, count) }; out.toByteArray() }
                require(bytes.size <= 2_000_000) { I18n.t(R.string.ui_253) }
                val snapshot = JSONObject(String(bytes, Charsets.UTF_8))
                require(snapshot.getString("format") == "sanad-family-v1") { I18n.t(R.string.ui_254) }
                val id = UUID.fromString(snapshot.getString("id")).toString()
                val profile = snapshot.getJSONObject("profile")
                val name = profile.getString("name").trim()
                require(name.isNotBlank() && name.length <= 300)
                val exportedAt = snapshot.getLong("at")
                require(exportedAt > 0)
                val lists = listOf("readings", "members", "tasks_v2", "medications", "labs").associateWith { snapshot.getJSONArray(it) }
                lists.forEach { (key, array) ->
                    require(array.length() <= 5000)
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        val fields = when (key) { "readings" -> listOf("type", "value"); "members" -> listOf("id", "name"); else -> listOf("id", "title") }
                        fields.forEach { require(item.get(it) is String) }
                        if (key == "readings") require(item.getLong("at") > 0)
                    }
                }
                AlertDialog.Builder(this).setTitle(I18n.pick("استيراد ملف $name؟", "Import $name?"))
                    .setMessage(I18n.pick("سيُحفظ ملف الأسرة على هذا الجهاز. إذا سبق استيراده ستُستبدل نسخة بياناته المحلية بهذا التصدير. تاريخ الملف: ${formatDue(exportedAt)}", "This file will replace a previous local import of the same family. Export date: ${formatDue(exportedAt)}"))
                    .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_257)) { _, _ ->
                        val file = "IMPORT-$id"
                        val families = JSONArray(prefs.getString("doctor_families", "[]"))
                        val updated = JSONArray()
                        for (i in 0 until families.length()) if (families.getJSONObject(i).getString("file") != file) updated.put(families.getJSONObject(i))
                        updated.put(JSONObject().put("name", I18n.pick("أسرة $name", "$name family")).put("patient", name).put("file", file))
                        val edit = prefs.edit().putString("doctor_families", updated.toString())
                            .putString("doctor_${file}_patient_profile", profile.toString()).putLong("doctor_${file}_exportedAt", exportedAt)
                        lists.forEach { (key, array) -> edit.putString("doctor_${file}_$key", array.toString()) }
                        edit.apply()
                        selectedFamily = demoFamilies.indexOfFirst { it.file == file }
                        show(Screen.PATIENT)
                    }.show()
            }
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_259)).setMessage(I18n.t(R.string.ui_260) + (e.message ?: "")).setPositiveButton(I18n.t(R.string.ui_217), null).show()
        }
    }

    private val cloud by lazy { CloudLink() }
    private var linkSubscription: com.google.firebase.firestore.ListenerRegistration? = null
    private var recordSubscription: com.google.firebase.firestore.ListenerRegistration? = null
    private var observedPrefs: android.content.SharedPreferences? = null
    private var cloudLinks = emptyList<com.google.firebase.firestore.DocumentSnapshot>()
    private var cloudList: LinearLayout? = null
    private var cloudLabel: TextView? = null
    private var cloudStatus = ""
    private var familyDoctorUid: String? = null
    private var familyLinkAccepted = false
    private var messageSubscription: com.google.firebase.firestore.ListenerRegistration? = null
    private var familyLinkExists = false
    private var cloudRecordUid: String? = null
    private var cloudGeneration = 0
    private val syncHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val sharedKeys = listOf("patient_profile", "readings", "members", "tasks_v2", "medications", "labs")
    private val syncWork = Runnable { publishFamily() }
    private val changes = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (role == Role.FAMILY && key in sharedKeys && prefs.getBoolean("cloud_sharing", false)) {
            syncHandler.removeCallbacks(syncWork); syncHandler.postDelayed(syncWork, 800)
        }
    }
    private fun cloudMessage(message: String) { cloudStatus = message; cloudLabel?.text = message }
    private fun cloudError(e: Exception?) = I18n.t(R.string.ui_262) + (e?.let { " (${it.javaClass.simpleName})" } ?: "")
    private fun clearCloudCache() {
        val edit = prefs.edit()
        prefs.all.keys.filter { it.startsWith("doctor_CLOUD-") }.forEach { edit.remove(it) }
        edit.apply()
    }
    private fun stopCloud() {
        messageSubscription?.remove(); messageSubscription = null
        familyDoctorUid = null; familyLinkAccepted = false
        cloudGeneration++
        linkSubscription?.remove(); linkSubscription = null
        recordSubscription?.remove(); recordSubscription = null
        syncHandler.removeCallbacks(syncWork)
        observedPrefs?.unregisterOnSharedPreferenceChangeListener(changes); observedPrefs = null
        clearCloudCache(); cloudLinks = emptyList(); cloudRecordUid = null
        familyLinkExists = false; cloudLabel = null; cloudList = null
    }
    private fun startCloud() {
        stopCloud()
        val uid = signedInUid ?: return
        val generation = cloudGeneration
        cloudMessage(I18n.t(R.string.ui_261))
        if (role == Role.FAMILY) {
            observedPrefs = prefs.also { it.registerOnSharedPreferenceChangeListener(changes) }
            linkSubscription = cloud.familyLink(uid) { value, error ->
                if (generation != cloudGeneration || signedInUid != uid) return@familyLink
                if (error != null) { cloudMessage(cloudError(error)); return@familyLink }
                familyLinkExists = value?.exists() == true
                val status = value?.getString("status")
                familyDoctorUid = value?.getString("doctorUid")
                familyLinkAccepted = status == "accepted"
                if (current == Screen.DOCTOR) show(Screen.DOCTOR)
                cloudMessage(when (status) { "accepted" -> I18n.t(R.string.ui_263); "pending" -> I18n.t(R.string.ui_264); "rejected" -> I18n.t(R.string.ui_265); else -> I18n.t(R.string.ui_266) })
                if (status in listOf("pending", "accepted") && prefs.getBoolean("cloud_sharing", false)) publishFamily()
            }
        } else {
            cloud.doctor(uid) { value, error ->
                if (generation != cloudGeneration) return@doctor
                if (error != null) cloudMessage(cloudError(error))
                else if (value?.exists() == true) {
                    prefs.edit().putString("doctor_short_id", value.getString("code")).putString("doctor_name", value.getString("name")).putBoolean("doctor_cloud_registered", true).apply()
                    cloudMessage((I18n.t(R.string.ui_267) + value.getString("code")))
                    if (current == Screen.HOME) show(Screen.HOME)
                }
            }
            linkSubscription = cloud.doctorLinks(uid) { values, error ->
                if (generation != cloudGeneration || signedInUid != uid) return@doctorLinks
                if (error != null) {
                    cloudLinks = emptyList(); recordSubscription?.remove(); clearCloudCache()
                    cloudMessage(cloudError(error)); renderCloudLinks()
                    if (cloudRecordUid != null) { cloudRecordUid = null; show(Screen.HOME) }
                    return@doctorLinks
                }
                val selected = demoFamilies.getOrNull(selectedFamily)?.file
                cloudLinks = values.orEmpty().sortedBy { it.id }
                selectedFamily = demoFamilies.indexOfFirst { it.file == selected }.coerceAtLeast(0)
                if (cloudRecordUid != null && cloudLinks.none { it.id == cloudRecordUid && it.getString("status") == "accepted" }) {
                    recordSubscription?.remove(); clearCloudCache(); cloudRecordUid = null; show(Screen.HOME)
                }
                cloudMessage(I18n.t(R.string.ui_268))
                renderCloudLinks()
            }
        }
    }
    private fun registerCloudDoctor(name: String, attempt: Int = 0) {
        val uid = signedInUid ?: return
        val generation = cloudGeneration
        val letters = name.codePoints().toArray().filter { Character.isLetter(it) }
        if (letters.size < 2 || name.length > 150) { Toast.makeText(this, I18n.t(R.string.ui_269), Toast.LENGTH_LONG).show(); return }
        val code = String(letters.take(2).toIntArray(), 0, 2) + (1..6).joinToString("") { java.security.SecureRandom().nextInt(10).toString() }
        cloudMessage(I18n.t(R.string.ui_270))
        cloud.registerDoctor(uid, name, code) { registered, error ->
            if (generation != cloudGeneration || signedInUid != uid) return@registerDoctor
            if (error != null) { cloudMessage(cloudError(error)); Toast.makeText(this, cloudStatus, Toast.LENGTH_LONG).show(); return@registerDoctor }
            prefs.edit().putString("doctor_short_id", registered).putString("doctor_name", name).putBoolean("doctor_cloud_registered", true).apply()
            show(Screen.HOME)
        }
    }
    private fun cloudFamilyPanel() {
        page.append(label(I18n.t(R.string.ui_271), 17f, true))
        cloudLabel = label(cloudStatus, 14f, color = muted).also { page.append(it) }
        if (!familyLinkExists) {
        val code = input(I18n.t(R.string.ui_272))
        page.append(code)
        page.append(button(I18n.t(R.string.ui_273)) {
            val uid = signedInUid ?: return@button
            val generation = cloudGeneration
            val value = code.text.toString().trim()
            if (value.codePointCount(0, value.length) != 8 || value.contains('/')) { code.error = I18n.t(R.string.ui_274); return@button }
            cloud.lookup(value) { found, error ->
                if (generation != cloudGeneration || signedInUid != uid) return@lookup
                if (error != null || found?.exists() != true) { cloudMessage(if (error == null) I18n.t(R.string.ui_275) else cloudError(error)); return@lookup }
                val doctorUid = found.getString("uid") ?: return@lookup
                val name = found.getString("name").orEmpty()
                if (doctorUid == uid) { cloudMessage(I18n.t(R.string.ui_276)); return@lookup }
                val familyName = JSONObject(prefs.getString("patient_profile", "{}")).optString("name").trim()
                if (familyName.isBlank() || familyName.length > 150) { cloudMessage(I18n.t(R.string.ui_277)); return@lookup }
                AlertDialog.Builder(this).setTitle(I18n.pick("ربط الأسرة بالطبيب $name؟", "Connect with Dr. $name?"))
                    .setMessage(I18n.t(R.string.ui_279))
                    .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_280)) { _, _ ->
                        if (generation != cloudGeneration) return@setPositiveButton
                        cloud.request(uid, doctorUid, value, familyName) { failure ->
                            if (generation != cloudGeneration) return@request
                            if (failure != null) cloudMessage(cloudError(failure)) else {
                                prefs.edit().putBoolean("cloud_sharing", true).apply(); familyLinkExists = true; publishFamily()
                            }
                        }
                    }.show()
            }
        })
        }
        if (familyLinkExists) {
        page.append(button(I18n.t(R.string.ui_281), false) {
            if (!familyLinkExists) cloudMessage(I18n.t(R.string.ui_282)) else {
                AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_283)).setMessage(I18n.t(R.string.ui_284))
                    .setNegativeButton(I18n.t(R.string.ui_121), null).setPositiveButton(I18n.t(R.string.ui_285)) { _, _ -> prefs.edit().putBoolean("cloud_sharing", true).apply(); publishFamily() }.show()
            }
        })
        page.append(button(I18n.t(R.string.ui_286), false) {
            val uid = signedInUid ?: return@button
            val generation = cloudGeneration
            AlertDialog.Builder(this).setTitle(I18n.t(R.string.ui_287)).setMessage(I18n.t(R.string.ui_288))
                .setNegativeButton(I18n.t(R.string.ui_59), null).setPositiveButton(I18n.t(R.string.ui_289)) { _, _ ->
                    cloud.revoke(uid) { error ->
                        if (generation != cloudGeneration) return@revoke
                        if (error != null) cloudMessage(cloudError(error)) else { prefs.edit().putBoolean("cloud_sharing", false).apply(); familyLinkExists = false; cloudMessage(I18n.t(R.string.ui_290)) }
                    }
                }.show()
        })
        }
    }
    private fun publishFamily() {
        val uid = signedInUid ?: return
        if (role != Role.FAMILY || !familyLinkExists || !prefs.getBoolean("cloud_sharing", false)) return
        val generation = cloudGeneration
        val snapshot = JSONObject().put("profile", JSONObject(prefs.getString("patient_profile", "{}")))
        listOf("readings", "members", "tasks_v2", "medications", "labs").forEach { snapshot.put(it, JSONArray(prefs.getString(it, "[]"))) }
        cloudMessage(I18n.t(R.string.ui_291))
        cloud.publish(uid, snapshot.toString()) { error ->
            if (generation != cloudGeneration || !familyLinkExists) return@publish
            cloudMessage(if (error == null) I18n.t(R.string.ui_292) else cloudError(error))
        }
    }
    private fun renderCloudLinks() {
        val list = cloudList ?: return
        list.removeAllViews()
        if (cloudLinks.isEmpty()) list.append(card(I18n.t(R.string.ui_293)))
        cloudLinks.forEach { link ->
            val status = link.getString("status")
            list.append(card(link.getString("familyName") ?: I18n.t(R.string.ui_42), when(status) { "accepted" -> I18n.t(R.string.ui_294); "pending" -> I18n.t(R.string.ui_295); else -> I18n.t(R.string.ui_296) }).apply {
                if (status == "pending") {
                    append(button(I18n.t(R.string.ui_297)) { cloud.decide(link.id, "accepted") { if (it != null) cloudMessage(cloudError(it)) } })
                    append(button(I18n.t(R.string.ui_298), false) { cloud.decide(link.id, "rejected") { if (it != null) cloudMessage(cloudError(it)) } })
                }
                if (status == "accepted") append(button(I18n.t(R.string.ui_299)) { openCloudFamily(link.id) })
            })
        }
    }
    private fun openCloudFamily(uid: String) {
        val generation = cloudGeneration
        var firstSnapshot = true
        recordSubscription?.remove(); clearCloudCache(); cloudRecordUid = uid
        cloudMessage(I18n.t(R.string.ui_300))
        recordSubscription = cloud.record(uid) { value, error ->
            if (generation != cloudGeneration || cloudRecordUid != uid) return@record
            if (error != null) { clearCloudCache(); cloudRecordUid = null; show(Screen.HOME); cloudMessage(cloudError(error)); return@record }
            if (value?.exists() != true) { cloudMessage(I18n.t(R.string.ui_301)); return@record }
            try {
                val snapshot = JSONObject(value.getString("payload") ?: "{}")
                val profile = snapshot.getJSONObject("profile")
                val edit = prefs.edit().putString("doctor_CLOUD-${uid}_patient_profile", profile.toString())
                listOf("readings", "members", "tasks_v2", "medications", "labs").forEach { key ->
                    val array = snapshot.getJSONArray(key)
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        val fields = when(key) { "readings" -> listOf("type", "value"); "members" -> listOf("id", "name"); else -> listOf("id", "title") }
                        fields.forEach { require(item.get(it) is String) }
                        if (key == "readings") item.getLong("at")
                    }
                    edit.putString("doctor_CLOUD-${uid}_$key", array.toString())
                }
                edit.putLong("doctor_CLOUD-${uid}_exportedAt", value.getTimestamp("updatedAt")?.toDate()?.time ?: 0).apply()
                selectedFamily = demoFamilies.indexOfFirst { it.file == "CLOUD-$uid" }
                if (selectedFamily < 0) { selectedFamily = 0; return@record }
                if (firstSnapshot) {
                    firstSnapshot = false
                    show(Screen.PATIENT)
                } else if (current in listOf(Screen.PATIENT, Screen.RECORD, Screen.READINGS, Screen.TASKS, Screen.MEDICATIONS, Screen.LABS, Screen.MEMBERS)) {
                    show(current)
                }
            } catch (_: Exception) { cloudMessage(I18n.t(R.string.ui_302)) }
        }
    }
    private fun conversation() {
        val uid = signedInUid ?: return
        val familyUid = if (role == Role.FAMILY) uid else
            demoFamilies.getOrNull(selectedFamily)?.file?.takeIf { it.startsWith("CLOUD-") }?.removePrefix("CLOUD-")
        val doctorUid = if (role == Role.DOCTOR) uid else familyDoctorUid
        val accepted = if (role == Role.FAMILY) familyLinkAccepted else cloudLinks.any { it.id == familyUid && it.getString("status") == "accepted" }
        page.append(label(I18n.t(R.string.ui_138), 17f, true))
        if (!accepted || familyUid == null || doctorUid == null) {
            page.append(label(if (role == Role.FAMILY) I18n.t(R.string.ui_303) else I18n.t(R.string.ui_304), 14f, color = muted))
            if (role == Role.DOCTOR) cloudLinks.filter { it.getString("status") == "accepted" }.forEach { link ->
                page.append(button(link.getString("familyName") ?: I18n.t(R.string.ui_42), false) {
                    selectedFamily = demoFamilies.indexOfFirst { it.file == "CLOUD-${link.id}" }.coerceAtLeast(0)
                    show(Screen.DOCTOR)
                })
            }
            return
        }
        val generation = cloudGeneration
        val list = column(); page.append(list)
        val status = label(I18n.t(R.string.ui_305), 13f, color = muted); page.append(status)
        val body = input(I18n.t(R.string.ui_306)).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2; maxLines = 5
            filters = arrayOf(android.text.InputFilter.LengthFilter(2000))
        }
        page.append(body)
        val send = button(I18n.t(R.string.ui_307)) { }
        send.setOnClickListener {
            val message = body.text.toString().trim()
            if (message.isEmpty()) { body.error = I18n.t(R.string.ui_306); return@setOnClickListener }
            send.isEnabled = false; status.text = I18n.t(R.string.ui_308)
            cloud.sendMessage(familyUid, doctorUid, uid, message) { error ->
                if (generation != cloudGeneration || current != Screen.DOCTOR) return@sendMessage
                send.isEnabled = true
                if (error == null) { body.text.clear(); status.text = I18n.t(R.string.ui_309) }
                else status.text = I18n.t(R.string.ui_310)
            }
        }
        page.append(send)
        messageSubscription = cloud.messages(familyUid, doctorUid) { values, error ->
            if (generation != cloudGeneration || current != Screen.DOCTOR) return@messages
            list.removeAllViews()
            if (error != null) {
                status.text = I18n.t(R.string.ui_311)
                send.isEnabled = false
            } else {
                send.isEnabled = true
                status.text = if (values.isNullOrEmpty()) I18n.t(R.string.ui_312) else ""
                values.orEmpty().sortedBy { it.getTimestamp("at")?.toDate()?.time ?: Long.MAX_VALUE }.takeLast(100).forEach { item ->
                    val mine = item.getString("sender") == uid
                    val title = if (mine) I18n.t(R.string.ui_313) else if (role == Role.FAMILY) I18n.t(R.string.ui_31) else I18n.t(R.string.ui_314)
                    list.append(card(title, item.getString("body").orEmpty()).apply {
                        background = panel(if (mine) backgroundColor else Color.WHITE, 12, true)
                        item.getTimestamp("at")?.toDate()?.time?.let { append(label(formatDue(it), 11f, color = muted), 0) }
                    })
                }
            }
        }
    }

    private fun cloudReadOnly() = role == Role.DOCTOR && demoFamilies.getOrNull(selectedFamily)?.file?.startsWith("CLOUD-") == true
    private fun lockCloudEdits(view: View) {
        if (view is CheckBox || view is EditText) view.isEnabled = false
        if (view is Button && listOf(I18n.t(R.string.ui_315), I18n.t(R.string.ui_234), I18n.t(R.string.ui_151), I18n.t(R.string.ui_122), I18n.t(R.string.ui_316)).any { view.text.startsWith(it) }) view.isEnabled = false
        if (view is android.view.ViewGroup) for (i in 0 until view.childCount) lockCloudEdits(view.getChildAt(i))
    }

}
