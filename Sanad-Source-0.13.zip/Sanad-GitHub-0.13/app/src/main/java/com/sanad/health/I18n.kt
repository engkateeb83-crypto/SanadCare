package com.sanad.health

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import android.view.View
import java.util.Locale

/** Device preference only. Account roles and user-authored records are never translated. */
object I18n {
    private lateinit var localized: Context
    var language: String = "ar"
        private set
    val locale: Locale get() = Locale.forLanguageTag(language)
    val direction: Int get() = if (language == "ar") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

    fun wrap(context: Context): Context {
        language = context.getSharedPreferences("sanad_settings", Context.MODE_PRIVATE)
            .getString("language", "ar").let { if (it == "en") "en" else "ar" }
        val config = Configuration(context.resources.configuration).apply {
            setLocales(LocaleList(I18n.locale))
            setLayoutDirection(I18n.locale)
        }
        localized = context.applicationContext.createConfigurationContext(config)
        return context.createConfigurationContext(config)
    }

    fun setLanguage(context: Context, value: String) {
        require(value == "ar" || value == "en")
        context.getSharedPreferences("sanad_settings", Context.MODE_PRIVATE).edit().putString("language", value).apply()
    }

    fun t(id: Int): String = localized.getString(id)
    fun pick(arabic: String, english: String): String = if (language == "en") english else arabic
    fun measurement(value: String): String = when (value) {
        "ضغط الدم (mmHg)" -> t(R.string.ui_96)
        "الأكسجين (%)" -> t(R.string.ui_97)
        "السكر (mg/dL)" -> t(R.string.ui_98)
        else -> value
    }
}
