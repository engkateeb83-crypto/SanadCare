package com.sanad.health

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.DocumentSnapshot

/** All authorization is enforced by firestore.rules; UI roles are not privileges. */
class CloudLink {
    private val db = FirebaseFirestore.getInstance().apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder().setPersistenceEnabled(false).build()
    }
    fun accountRole(uid: String, selected: String?, done: (String?, Exception?) -> Unit) {
        val ref = db.collection("accounts").document(uid)
        db.runTransaction { tx ->
            val existing = tx.get(ref)
            if (existing.exists()) existing.getString("role") else {
                val doctor = tx.get(db.collection("doctors").document(uid))
                val family = tx.get(db.collection("links").document(uid))
                val assigned = if (doctor.exists()) "DOCTOR" else if (family.exists()) "FAMILY" else selected
                if (assigned != null) {
                    check(assigned in listOf("FAMILY", "DOCTOR"))
                    tx.set(ref, mapOf("role" to assigned))
                }
                assigned
            }
        }.addOnSuccessListener { done(it, null) }.addOnFailureListener { done(null, it) }
    }
    fun messages(familyUid: String, doctorUid: String, changed: (List<DocumentSnapshot>?, Exception?) -> Unit): ListenerRegistration =
        db.collection("links").document(familyUid).collection("messages")
            .whereEqualTo("doctorUid", doctorUid)
            .addSnapshotListener { value, error -> changed(value?.documents, error) }
    fun sendMessage(familyUid: String, doctorUid: String, sender: String, body: String, done: (Exception?) -> Unit) {
        db.collection("links").document(familyUid).collection("messages").add(mapOf(
            "doctorUid" to doctorUid, "sender" to sender, "body" to body, "at" to FieldValue.serverTimestamp()
        )).addOnSuccessListener { done(null) }.addOnFailureListener { done(it) }
    }
    fun registerDoctor(uid: String, name: String, code: String, done: (String?, Exception?) -> Unit) {
        val doctor = db.collection("doctors").document(uid)
        val codeRef = db.collection("doctorCodes").document(code)
        db.runTransaction { tx ->
            val old = tx.get(doctor)
            if (old.exists()) old.getString("code")!! else {
                check(!tx.get(codeRef).exists()) { I18n.t(R.string.ui_0) }
                tx.set(doctor, mapOf("code" to code, "name" to name))
                tx.set(codeRef, mapOf("uid" to uid, "name" to name))
                code
            }
        }.addOnSuccessListener { done(it, null) }.addOnFailureListener { done(null, it) }
    }
    fun doctor(uid: String, done: (DocumentSnapshot?, Exception?) -> Unit) {
        db.collection("doctors").document(uid).get(Source.SERVER).addOnSuccessListener { done(it, null) }.addOnFailureListener { done(null, it) }
    }
    fun lookup(code: String, done: (DocumentSnapshot?, Exception?) -> Unit) {
        db.collection("doctorCodes").document(code).get(Source.SERVER).addOnSuccessListener { done(it, null) }.addOnFailureListener { done(null, it) }
    }
    fun request(uid: String, doctorUid: String, code: String, familyName: String, done: (Exception?) -> Unit) {
        val ref = db.collection("links").document(uid)
        db.runTransaction { tx ->
            check(!tx.get(ref).exists()) { I18n.t(R.string.ui_1) }
            tx.set(ref, mapOf("familyUid" to uid, "doctorUid" to doctorUid, "code" to code, "familyName" to familyName, "status" to "pending"))
        }.addOnSuccessListener { done(null) }.addOnFailureListener { done(it) }
    }
    fun familyLink(uid: String, changed: (DocumentSnapshot?, Exception?) -> Unit): ListenerRegistration =
        db.collection("links").document(uid).addSnapshotListener { value, error -> changed(value, error) }
    fun doctorLinks(uid: String, changed: (List<DocumentSnapshot>?, Exception?) -> Unit): ListenerRegistration =
        db.collection("links").whereEqualTo("doctorUid", uid).addSnapshotListener { value, error -> changed(value?.documents, error) }
    fun decide(familyUid: String, status: String, done: (Exception?) -> Unit) {
        db.collection("links").document(familyUid).update("status", status).addOnSuccessListener { done(null) }.addOnFailureListener { done(it) }
    }
    fun revoke(uid: String, done: (Exception?) -> Unit) {
        db.collection("links").document(uid).delete().addOnSuccessListener { done(null) }.addOnFailureListener { done(it) }
    }
    fun publish(uid: String, payload: String, done: (Exception?) -> Unit) {
        if (payload.toByteArray(Charsets.UTF_8).size > 700000) { done(IllegalArgumentException(I18n.t(R.string.ui_2))); return }
        db.collection("records").document(uid).set(mapOf("payload" to payload, "updatedAt" to FieldValue.serverTimestamp()))
            .addOnSuccessListener { done(null) }.addOnFailureListener { done(it) }
    }
    fun record(uid: String, changed: (DocumentSnapshot?, Exception?) -> Unit): ListenerRegistration =
        db.collection("records").document(uid).addSnapshotListener { value, error -> changed(value, error) }
}
