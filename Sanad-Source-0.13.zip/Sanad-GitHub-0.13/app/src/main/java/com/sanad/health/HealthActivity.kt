package com.sanad.health

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.BloodPressureRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.temporal.ChronoUnit

class HealthActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(I18n.wrap(newBase))
    }

    private lateinit var result: TextView
    private val permissions = setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(BloodPressureRecord::class)
    )
    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        result.text = if (granted.containsAll(permissions)) I18n.t(R.string.ui_3) else I18n.t(R.string.ui_4)
    }
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 24) }
        val title = TextView(this).apply { text = I18n.t(R.string.ui_5); textSize = 26f; setTextColor(Color.rgb(20, 95, 105)) }
        val intro = TextView(this).apply { text = I18n.t(R.string.ui_6); textSize = 16f }
        val allow = Button(this).apply { text = I18n.t(R.string.ui_7); setOnClickListener { requestAccess() } }
        val read = Button(this).apply { text = I18n.t(R.string.ui_8); setOnClickListener { readMeasurements() } }
        result = TextView(this).apply { text = I18n.t(R.string.ui_9); textSize = 17f; setPadding(0, 22, 0, 0) }
        listOf(title,intro,allow,read,result).forEach { layout.addView(it) }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
    private fun clientOrNull(): HealthConnectClient? {
        val status = HealthConnectClient.getSdkStatus(this)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            result.text = I18n.pick("Health Connect غير جاهز أو غير متاح. تأكد من تثبيته وتحديثه. (status=$status)", "Health Connect is unavailable. Install or update it. (status=$status)")
            return null
        }
        return HealthConnectClient.getOrCreate(this)
    }
    private fun requestAccess() {
        if (clientOrNull() != null) permissionLauncher.launch(permissions)
    }
    private fun readMeasurements() {
        val client = clientOrNull() ?: return
        scope.launch {
            result.text = I18n.t(R.string.ui_11)
            try {
                val granted = client.permissionController.getGrantedPermissions()
                val time = TimeRangeFilter.between(Instant.now().minus(7, ChronoUnit.DAYS), Instant.now())
                val out = mutableListOf<String>()
                if (HealthPermission.getReadPermission(HeartRateRecord::class) in granted) {
                    val records = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, time, pageSize = 100)).records
                    val latest = records.flatMap { record -> record.samples.map { it.time to it.beatsPerMinute } }.maxByOrNull { it.first }
                    out += if (latest == null) I18n.t(R.string.ui_12) else I18n.pick("النبض: ${latest.second} نبضة/دقيقة | ${latest.first}", "Heart rate: ${latest.second} bpm | ${latest.first}")
                } else out += I18n.t(R.string.ui_14)
                if (HealthPermission.getReadPermission(OxygenSaturationRecord::class) in granted) {
                    val records = client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, time, pageSize = 100)).records
                    val latest = records.maxByOrNull { it.time }
                    out += if (latest == null) I18n.t(R.string.ui_15) else I18n.pick("الأكسجين: ${latest.percentage.value}% | ${latest.time}", "Oxygen: ${latest.percentage.value}% | ${latest.time}")
                } else out += I18n.t(R.string.ui_17)
                if (HealthPermission.getReadPermission(BloodPressureRecord::class) in granted) {
                    val records = client.readRecords(ReadRecordsRequest(BloodPressureRecord::class, time, pageSize = 100)).records
                    val latest = records.maxByOrNull { it.time }
                    out += if (latest == null) I18n.t(R.string.ui_18) else I18n.pick("الضغط: ${latest.systolic.inMillimetersOfMercury.toInt()}/${latest.diastolic.inMillimetersOfMercury.toInt()} mmHg | ${latest.time}", "Blood pressure: ${latest.systolic.inMillimetersOfMercury.toInt()}/${latest.diastolic.inMillimetersOfMercury.toInt()} mmHg | ${latest.time}")
                } else out += I18n.t(R.string.ui_20)
                result.text = out.joinToString("\n\n") + I18n.t(R.string.ui_21)
            } catch (e: Exception) { result.text = I18n.pick("تعذر قراءة البيانات: ${e.message}", "Unable to read data: ${e.message}") }
        }
    }
}
